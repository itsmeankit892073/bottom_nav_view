package com.ankit.bottom_navigation_view;

import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.ankit.bottom_navigation_view.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    BottomNavigationView btmnav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        btmnav=findViewById(R.id.btmview);
btmnav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        int id=item.getItemId();
        if(id==R.id.home){
           fragmang(new homeFragment(),false);

        }
       else if(id==R.id.status){
     fragmang(new StatusFragment(),false);
        }
        else if(id==R.id.calls){
fragmang(new callsFragment(),false);
        }
        else if(id==R.id.communinty){
fragmang(new communityFragment(),false);
        }
        else if(id==R.id.chat){
fragmang(new ChatFragment(),false);
        }
        else{
fragmang(new homeFragment(),true);
        }

       return true;
    }

}); btmnav.setSelectedItemId(R.id.calls);

    }public  void fragmang(Fragment fragment,boolean flag){
        FragmentManager fm=getSupportFragmentManager();
        FragmentTransaction ft=fm.beginTransaction();

        if(flag){
            ft.add(R.id.container,fragment);
        }
        else {
            ft.replace(R.id.container,fragment);
        }
        ft.commit();
    }
}